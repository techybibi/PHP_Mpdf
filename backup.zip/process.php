<?php
// include("mpdf/mpdf.php");

// $mpdf = new mPDF();
// $mpdf->WriteHTML('<h1>Hello world!</h1>');
// $mpdf->Output()

//$firstName = $_POST['firstName'];
//echo $firstName;
//workspace

//$photoapplicant =$_POST['filephoto'];
$preferenceOne =$_POST['pre1'];
$preferenceTwo =$_POST['pre2'];
$preferenceThree =$_POST['pre3'];
$applicantName =$_POST['Aname'];
$initialDetails =$_POST['Idetails'];
$applicantAge =$_POST['Aage'];
$placeOfBirth =$_POST['Pbirth'];
$guardianName =$_POST['Gname'];
$relationGuardian =$_POST['Relation'];
$occupationGuardian =$_POST['Occu'];
$annualIncome =$_POST['Aincome'];
$guardianAddress =$_POST['Gaddress'];
$guardianPhone =$_POST['Gphone'];
$communicationAddress =$_POST['Caddress'];
$communicationPhone =$_POST['Cphone'];
$applicantReligion =$_POST['Religion'];
//$eligiblePdf =$_POST['file1'];


$ePassed1 =$_POST['Exampassed1'];
$eName1 =$_POST['Examname1'];
$yStudy1 =$_POST['Yearstudy1'];
$bName1 =$_POST['Boardname1'];
$yPassing1 =$_POST['Yearpassing1'];
$regNO1 =$_POST['Regno1'];
$iName1 =$_POST['Institutionname1'];

$ePassed2 =$_POST['Exampassed2'];
$eName2 =$_POST['Examname2'];
$yStudy2 =$_POST['Yearstudy2'];
$bNmae2 =$_POST['Boardname2'];
$yPassing2 =$_POST['Yearpassing2'];
$regNo2 =$_POST['Regno2'];
$iName2 =$_POST['Institutionname2'];

$appearTime =$_POST['appeartime'];
$lChoice =$_POST['Lchoice'];
$consider =$_POST['Consideration'];
$sAddress =$_POST['Saddress'];

$nameExamPass =$_POST['NameExamPassed'];
$yearOfPass =$_POST['YearOfPass'];
$nameOfBoard =$_POST['NameOfBoard'];
$specifyRegno =$_POST['Specifyregno'];

$englishNta =$_POST['EnglishNTA'];
$englishMs =$_POST['EnglishMS'];
$englishMm =$_POST['EnglishMM'];
$englishPm =$_POST['EnglishPM'];

$langNta =$_POST['LanguageNTA'];
$langMs =$_POST['LanguageMS'];
$langMm =$_POST['LanguageMM'];
$langPm =$_POST['LanguagePM'];


$firstNta =$_POST['FirstNTA'];
$firstMs =$_POST['FirstMS'];
$firstMm =$_POST['FirstMM'];
$firstPm =$_POST['FirstPM'];


$secondNta =$_POST['SecondNTA'];
$secondMs =$_POST['SecondMS'];
$secondMm =$_POST['SecondMM'];
$secondPm =$_POST['SecondPM'];


$thirdNta =$_POST['ThirdNTA'];
$thirdMs =$_POST['ThirdMS'];
$thirdMm =$_POST['ThirdMM'];
$thirdPm =$_POST['ThirdPM'];


$fourthNta =$_POST['FourthNTA'];
$fourthMs =$_POST['FourthMS'];
$fourthMm =$_POST['FourthMM'];
$fourthPm =$_POST['FourthPM'];

$fifthNta =$_POST['FifthNTA'];
$fifthMs =$_POST['FifthMS'];
$fifthMm =$_POST['FifthMM'];
$fifthPm =$_POST['FifthPM'];

$dDate =$_POST['Ddate'];
$nameApplicant =$_POST['Nameofapplicant'];
//$fileSig =$_POST['filesig'];
//$fileGSig =$_POST['fileGsig'];


//workspace2

echo $preferenceOne."</br>";
echo $preferenceTwo."</br>"; 
echo $preferenceThree."</br>";
echo $applicantName."</br>"; 
echo $initialDetails."</br>";
echo $applicantAge."</br>"; 
echo $placeOfBirth."</br>"; 
echo $guardianName."</br>"; 
echo $relationGuardian."</br>"; 
echo $occupationGuardian."</br>"; 
echo $annualIncome."</br>";
echo $guardianAddress."</br>"; 
echo $guardianPhone."</br>"; 
echo $communicationAddress."</br>"; 
echo $communicationPhone."</br>";
echo $applicantReligion."</br>"; 
//echo $eligiblePdf; 


echo $ePassed1."</br>"; 
echo $eName1."</br>"; 
echo $yStudy1."</br>"; 
echo $bName1."</br>"; 
echo $yPassing1."</br>"; 
echo $regNO1."</br>";  
echo $iName1."</br>";  

echo $ePassed2."</br>";  
echo $eName2."</br>";  
echo $yStudy2."</br>";  
echo $bNmae2."</br>";  
echo $yPassing2."</br>";  
echo $regNo2."</br>"; 
echo $iName2."</br>";  

echo $appearTime."</br>";  
echo $lChoice."</br>";  
echo $consider."</br>";  
echo $sAddress."</br>"; 

echo $nameExamPass."</br>";  
echo $yearOfPass."</br>";  
echo $nameOfBoard."</br>";  
echo $specifyRegno."</br>";  

echo $englishNta."</br>"; 
echo $englishMs."</br>";  
echo $englishMm."</br>";  
echo $englishPm."</br>"; 


echo $langNta."</br>"; 
echo $langMs."</br>";
echo $langMm."</br>"; 
echo $langPm."</br>";  


echo $firstNta."</br>";  
echo $firstMs."</br>";  
echo $firstMm."</br>"; 
echo $firstPm."</br>";  


echo $secondNta."</br>";  
echo $secondMs."</br>";  
echo $secondMm."</br>"; 
echo $secondPm."</br>";  


echo $thirdNta."</br>";  
echo $thirdMs."</br>";  
echo $thirdMm."</br>"; 
echo $thirdPm."</br>"; 


echo $fourthNta."</br>";  
echo $fourthMs."</br>"; 
echo $fourthMm."</br>"; 
echo $fourthPm."</br>";  

echo $fifthNta."</br>";  
echo $fifthMs."</br>";  
echo $fifthMm."</br>";  
echo $fifthPm."</br>";  

echo $dDate."</br>";  
echo $nameApplicant."</br>";  
//echo $fileSig;  
//echo $fileGSig; 








?>